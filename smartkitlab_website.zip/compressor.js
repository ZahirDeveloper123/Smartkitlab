function compressImage() {
  const input = document.getElementById('imageInput');
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d');
  const link = document.getElementById('downloadLink');

  if (input.files && input.files[0]) {
    const img = new Image();
    const reader = new FileReader();
    reader.onload = function(e) {
      img.onload = function() {
        const scale = 0.5;
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(function(blob) {
          const url = URL.createObjectURL(blob);
          link.href = url;
          link.style.display = 'inline';
        }, 'image/jpeg', 0.7);
      }
      img.src = e.target.result;
    };
    reader.readAsDataURL(input.files[0]);
  }
}